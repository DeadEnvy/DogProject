#Marcus Mamott - Hello World
#September 14, 2018

class HelloWorld
    def self.hello(greeting = 'World')
        "Hello, #{greeting}!"
    end
end